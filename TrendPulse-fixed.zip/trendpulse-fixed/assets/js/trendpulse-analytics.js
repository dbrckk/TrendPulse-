// assets/js/trendpulse-analytics.js

(function () {
  const endpoint = "https://api.trend-pulse.shop/track";

  function sendEvent(type, data = {}) {
    try {
      fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          type,
          data,
          timestamp: Date.now(),
          url: window.location.href,
          userAgent: navigator.userAgent
        })
      });
    } catch (e) {
      console.log("Analytics error:", e);
    }
  }

  function trackPageView() {
    sendEvent("page_view", {
      path: window.location.pathname
    });
  }

  function trackClick(e) {
    const link = e.target.closest("a");
    if (!link) return;

    if (link.href && link.href.includes("amazon.com")) {
      sendEvent("affiliate_click", {
        href: link.href,
        text: link.textContent.trim()
      });
    }
  }

  function trackProductView() {
    // BUG FIX: Product pages use clean URL path /product/:slug, not ?asin= query params.
    // Extract identifier from the path instead of query string.
    const parts = window.location.pathname.split("/").filter(Boolean);
    if (parts[0] === "product" && parts[1]) {
      const identifier = decodeURIComponent(parts[1]);
      sendEvent("product_view", { identifier });
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    trackPageView();
    trackProductView();
    document.addEventListener("click", trackClick);
  });
})();
